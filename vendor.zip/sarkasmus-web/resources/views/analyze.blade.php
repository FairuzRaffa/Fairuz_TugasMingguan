@extends('layouts.app')
@section('title', 'Nama Halaman')
@section('content')
   <!-- isi halaman -->
@endsection
