

<?php $__env->startSection('content'); ?>
<h1 class="text-center">Data Mahasiswa</h1>
    <div class="row">
        <button type="button" class="btn btn-success mb-2">Success</button>
    </div>

    <table class="table">
  <thead>
    <tr>
        <th scope="col">no</th>    
      <th scope="col">nama</th>
      <th scope="col">nim</th>
      <th scope="col">prodi</th>
      <th scope="col">email</th>
      <th scope="col">no hp</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>Fairuz</td>
      <td>13242420039</td>
      <td>Teknologi Informasi</td>
      <td>fairuzalif102</td>
      <td>082233445566</td>
      <td>
        <button type="button" class="btn btn-primary">Primary</button>
        <button type="button" class="btn btn-danger">Danger</button>
      </td>
    </tr>
  </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MyProjectWeb\MyProjectWeb\resources\views/mahasiswa.blade.php ENDPATH**/ ?>