<?php $__env->startSection('content'); ?>
<div class="container">

    <div class="row justify-content-center">
        <div class="col-md-6 col-lg-4">

            <div class="card content-panel text-center">

                <div class="card-body">

                    <!-- Foto Profil -->
                    <img 
                        src="<?php echo e($foto); ?>" 
                        alt="Foto Profil"
                        class="rounded-circle mb-3"
                        style="width:140px; height:140px; object-fit:cover;"
                    >

                    <!-- Nama -->
                    <h3 class="mb-1"><?php echo e($nama); ?></h3>

                    <!-- Nomor HP -->
                    <p class="text-muted mb-4"><?php echo e($nohp); ?></p>

                    <!-- Button -->
                    <a href="#" class="btn btn-primary px-4">
                        Edit Profil
                    </a>

                </div>

            </div>

        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MyProjectWeb\MyProjectWeb\resources\views/profile.blade.php ENDPATH**/ ?>