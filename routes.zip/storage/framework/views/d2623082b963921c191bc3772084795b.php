<?php $__env->startSection('content'); ?>
<section class="hero position-relative">
    <div class="container">
        <div class="hero-inner text-center">

            <!-- Badge -->
            <span class="hero-badge mb-3 d-inline-block">
                Sistem Informasi Akademik
            </span>

            <!-- Title -->
            <h1 class="hero-title fw-bold">
                Laravel<span class="text-primary">TI</span>
            </h1>

            <!-- Subtitle -->
            <p class="hero-sub mt-3">
                Platform manajemen data mahasiswa berbasis Laravel
                dengan arsitektur modern, aman, dan profesional.
            </p>


        </div>
    </div>

</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MyProjectWeb\MyProjectWeb\resources\views/home.blade.php ENDPATH**/ ?>