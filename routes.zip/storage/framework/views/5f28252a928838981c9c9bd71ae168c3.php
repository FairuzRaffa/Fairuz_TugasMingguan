<?php $__env->startSection('content'); ?>
<div class="container">

    <div class="mb-5 text-center">
        <h1 class="fw-semibold">Berita Terbaru</h1>
        <p class="text-muted">Informasi dan update terbaru</p>
    </div>

    <div class="row g-4 justify-content-center">
        <?php $__currentLoopData = $beritas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-5 col-lg-4">

            <a href="/berita/<?php echo e($berita['slug']); ?>" class="text-decoration-none">
                <div class="card h-100 content-panel text-center">

                    <div class="card-body">
                        <h5 class="mb-2 text-primary">
                            <?php echo e($berita['judul']); ?>

                        </h5>

                        <span class="small text-muted">
                            <?php echo e($berita['penulis']); ?>

                        </span>
                    </div>

                </div>
            </a>

        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MyProjectWeb\MyProjectWeb\resources\views/berita.blade.php ENDPATH**/ ?>